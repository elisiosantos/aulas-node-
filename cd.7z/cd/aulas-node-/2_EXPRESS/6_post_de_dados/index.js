const express = require('express')
const app = express()


const path = require('path')
const caminho = path.join(__dirname,'templates')

app.get('/users/cadastrar', (req, res)=>{
    res.sendFile(`${caminho}/usuariosForm.html`)
})


app.get('/', (req, res)=>{
    res.sendFile(`${caminho}/index.html`)
})

app.get('/users/:id', (req, res)=>{
    const id = req.params.id
    console.log(`estamos ${id}`)
    res.sendFile(`${caminho}/usuarios.html`)
})




app.listen(3000)